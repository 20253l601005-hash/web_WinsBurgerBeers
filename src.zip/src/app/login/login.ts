import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html'
})
export class LoginComponent {
  usuario = '';
  password = '';
  errorLogin = false;

  constructor(private router: Router) {}

  iniciarSesion(form: NgForm) {
    if (form.valid) {
      if (this.usuario === 'admin' && this.password === '1234') {
        this.errorLogin = false;
        // Redirige directamente al panel administrativo
        this.router.navigate(['/admin']);
      } else {
        this.errorLogin = true;
      }
    }
  }
}