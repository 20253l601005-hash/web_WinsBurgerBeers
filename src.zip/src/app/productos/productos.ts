import { Component } from '@angular/core';

@Component({
  selector: 'app-productos',
  standalone: true,
  templateUrl: './productos.html',
  styleUrl: './productos.css'
})
export class ProductosComponent {}