import { Component } from '@angular/core';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [],
  templateUrl: './admin.html'
})
export class AdminComponent {
  // Vista meramente maquetada / estática
}